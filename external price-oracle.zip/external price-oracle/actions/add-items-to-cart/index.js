import {endpointSaga, takeEvery} from '@oracle-cx-commerce/store/utils';

/**
 * Saga that updates the application state. The code runs saga when the reducer flag is not supplied.
 * There are three options to consider:
 * 1. Create a custom action by default
 *    example: yarn occ create-action —-action-name getCurrency
 * 2. Create a custom action which invokes an endpoint with the same name as the action-name
 *    example: yarn occ create-action —-action-name getCurrency —-endpoint
 * 3. Create a custom action which invokes an endpoint with a different name as the action-name
 *    example: yarn occ create-action —-action-name testCurrency —-endpoint getCurrency
 */

function* addItemsToCartSaga(action) {
  let response = yield endpointSaga({action, payload: action.payload, endpointId: 'externalPrice'});
  if (response.ok) {
    /**
     * TODO : Extract the information from the response and append the required properties in the payload property under action.
     * perform the required logic here and then call the addItemsToCart endpoint.
     * externalPrice response will be present under the json property of response.
     */
    response = yield endpointSaga({action, payload: action.payload, endpointId: 'addItemsToCart'});
  }

  return response;
}

/**
 * The addItemsToCart action.
 *
 * This exports a generator function named "saga", whose presence signals OSF to pass
 * the generator function to Redux-Saga's middleware. Run API the first time the action
 * is dispatched via the store API.
 *
 * The generator function results in an asynchronous endpoint invocation
 * when the action is dispatched.
 */
export default {
  *saga() {
    yield takeEvery('addItemsToCart', addItemsToCartSaga);
  }
};

	
The guidelines from development are the ones that have already been mentioned and the source files(plugins.zip) are attached to this SR

Step1. Copy the add-items-to-cart folder from actions in plugin.zip and paste it in <workspace>/packages/app/<appName>/src/plugins/actions.
Step2. Open the <workspace>/packages/app/<appName>/src/plugins/actions/index.js and export the addItemsToCart action above all the OOTB actions.
Similarly export the meta from add-item-to-cart/meta and placed it above other exports.
Step3. Similarly copy the external-price folder from endpoints in plugin.zip and paste in it <workspace>/packages/app/<appName>/src/plugins/endpoints.
Step4. Make the relevant changes to index.js and meta.js files under <workspace>/packages/app/<appName>/src/plugins/endpoints such that the export is placed above the OOTB export as done above.
Step5: Fill in the required business logic in the action and endpoints stubs we provided. (Please refer to the TO-DO comments in the relevant files)


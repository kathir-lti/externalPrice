/*
 ** Copyright (c) 2020 Oracle and/or its affiliates.
 */

/* the exported endpoint should be placed above other OOTB exports to override any OOTB endpoint if present.
 * this can show up warning during actions build.
 */
export const externalPrice = () => import('./external-price');
export * from '@oracle-cx-commerce/wishlist-endpoints';
export * from '@oracle-cx-commerce/endpoints';
export * from '@oracle-cx-commerce/extensions-endpoints';

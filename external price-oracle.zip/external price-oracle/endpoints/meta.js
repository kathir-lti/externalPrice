/*
 ** Copyright (c) 2020 Oracle and/or its affiliates.
 */

/**
 * Export statement of custom endpoint meta should be placed above every export to override OOTB endpoint meta if already present.
 */

// eslint-disable-next-line @oracle-cx-commerce/osf/require-underscore-custom-exports
export {default as externalPrice} from './external-price/meta';
export * from '@oracle-cx-commerce/wishlist-endpoints/meta';
export * from '@oracle-cx-commerce/endpoints/meta';
export * from '@oracle-cx-commerce/extensions-endpoints/meta';

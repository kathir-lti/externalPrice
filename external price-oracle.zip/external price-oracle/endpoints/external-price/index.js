/*
 ** Copyright (c) 2020 Oracle and/or its affiliates.
 */

import {createEndpoint, getBodyAsJson} from '@oracle-cx-commerce/endpoints/factory';
import {populateError} from '@oracle-cx-commerce/endpoints/utils';

export const processInput = payload => {
  return {
    //params to be replaced with appropriate params required to invoke SSE.
    params: [`v1/configurations`],
    body: payload
  };
};

export const processOutput = async response => {
  const json = await getBodyAsJson(response);

  if (!response.ok) {
    return populateError(response, json);
  }
  /**
   * transform return of processOutput so that it can update the state as per the repository requirement.
   * In this case we are just passing the json object to action layer.(not updating the state).
   */

  return {json};
};

export default createEndpoint('extpost', {
  processInput,
  processOutput
});

module.exports = function (app, logger, config) {
    
    'use strict';

    const bodyParser = require('body-parser');
    //var CommerceSDK = require('../../occ/occ-sdk');
    //const occClient = new CommerceSDK(config);

    //logger.debug("routes/ebsIntegration.js : " + "importing controller");

    const {
        ebsGetBsasController,
        ebsGetBsaController
    } = require('../controllers');

    

    app.use(bodyParser.urlencoded({
        extended: true
    }));
    app.use(bodyParser.json());

    app.get(
        '/v1/ebs/bsas/:accountNumber',
        ebsGetBsasController
    );

    app.get(
        '/v1/ebs/bsas/:accountNumber/:bsaNumber',
        ebsGetBsaController
    );
};
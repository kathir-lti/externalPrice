module.exports = function (app, logger, config) {
    
    'use strict';

    const bodyParser = require('body-parser');
    //var CommerceSDK = require('../../occ/occ-sdk');
    //const occClient = new CommerceSDK(config);

    //logger.debug("routes/ebsIntegration.js : " + "importing controller");

    const {
        ebsIntegrationController
    } = require('../controllers');

    

    app.use(bodyParser.urlencoded({
        extended: true
    }));
    app.use(bodyParser.json());

    app.post(
        '/v1/ebs/integration',
        ebsIntegrationController
    );
};
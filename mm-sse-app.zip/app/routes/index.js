/*jslint node: true */

'use strict';
// index.js

module.exports = function (app, logger, config) {

    var fs = require('fs');
    

    function loadRoutes(error, files) {
        if (error) {
            throw error;
        } else {
            files.forEach(requireRoute);
        }
    }

    function requireRoute(file) {
        // Remove the file extension
        var f = file.substr(0, file.lastIndexOf('.'));
        // Do not require index.js (this file)
        if (f !== 'index') {
            // Require the controller
            logger.info("Adding route " + f);
            require('./' + f)(app, logger, config);
        }
    }

    try {
        fs.readdir(__dirname, loadRoutes);
    } catch (e) {
        logger.error(e.message);
    }

};
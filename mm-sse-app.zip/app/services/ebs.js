const occServices = {}

const mmConfig = require('../../config');

const ebsServices = {}

ebsServices.getServerUrl = () =>{
    return mmConfig.get("ebs.integration.url");
}


ebsServices.getBSAsPath = () =>{
    return mmConfig.get("ebs.integration.paths.bsas");
}

ebsServices.getBSAPath = () =>{
    return mmConfig.get("ebs.integration.paths.bsa");
}

ebsServices.getAuthentication = () =>{

    const token = Buffer.from(
        mmConfig.get("ebs.integration.username") 
            + ":" 
            + mmConfig.get("ebs.integration.password")).toString('base64');

    return "Basic " + token;

}

module.exports = ebsServices;
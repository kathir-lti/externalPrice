const Cache = require('node-cache');
const rp = require('request-promise');
const request = require("request");
const nconf = require('nconf');
const fs = require('fs');
const occClient = require('./occClient');
const logger = require('../../utils/GlobalLogger');

const skusCache = new Cache({stdTTL: 1800, checkperiod: 3600});
const priceGroupsCache = new Cache({stdTTL: 1800, checkperiod: 3600});

const occServices = {}

occServices.getAllSkus = function (params, allSkusParam, callback) {
    const cachedSkus = skusCache.get('ALL_SKUS');
    if (cachedSkus) {
        callback(null, cachedSkus);
    } else {
        if (!params) {
            params = 'expand=true&fields=repositoryId,displayName,primaryThumbImageURL';
        }
        let result = '';
        let allSkus = allSkusParam ? allSkusParam : [];
        occClient.get({
            url: '/ccadmin/v1/skus?' + params,
            callback: function (err, response) {
                if (response && response instanceof Buffer) {
                    result = JSON.parse(response.toString());
                } else {
                    result = response;
                }
                if (result) {
                    allSkus = allSkus.concat(result.items);
                    if (result.links && result.links.length > 0) {
                        const next = result.links.find(function (link) {
                            return link.rel === 'next';
                        });
                        if (next) {
                            const tempUrl = unescape(next.href);
                            const thisParams = tempUrl.split('?');
                            getAllSkus(thisParams[1], allSkus, callback);
                        } else {
                            skusCache.set('ALL_SKUS', allSkus);
                            callback(err, allSkus);
                        }
                    }
                }
            }
        });
    }
};

occServices.getAllPriceGroups = function (params, allPriceGroupsParam, callback) {
    const cachedPriceGroups = priceGroupsCache.get('ALL_PRICE_GROUPS');
    if (cachedPriceGroups) {
        callback(null, cachedPriceGroups);
    } else {
        if (!params) {
            params = 'fields=repositoryId,displayName'
        }

        let result = '';

        let allPriceGrups = allPriceGroupsParam ? allPriceGroupsParam : [];
        occClient.get({
            url: '/ccadmin/v1/priceListGroups?' + params,
            callback: function (err, response) {

                console.log("occServices.getAllPriceGroups >> err:", JSON.stringify(err));
                console.log("occServices.getAllPriceGroups >> response:", JSON.stringify(response));
                if (response && response instanceof Buffer) {
                    result = JSON.parse(response.toString());
                } else {
                    result = response;
                }
                if (result) {
                    allPriceGrups = allPriceGrups.concat(result.items);
                    if (result.links && result.links.length > 0) {
                        const next = result.links.find(function (link) {
                            return link.rel === 'next';
                        });
                        if (next) {
                            const tempUrl = unescape(next.href);
                            const thisParams = tempUrl.split('?');
                            getAllPriceGroups(thisParams[1], allPriceGrups, callback);
                        } else {
                            skusCache.set('ALL_PRICE_GROUPS', allPriceGrups);
                            callback(err, allPriceGrups);
                        }
                    }
                }
            }
        });
    }
};

occServices.getPriceGroupPrices = function (inputOptions, priceGroupBuffer, callback) {
    const cachedPriceGroups = priceGroupsCache.get('ALL_PRICE_GROUPS');
    

    if (cachedPriceGroups) {
        callback(null, cachedPriceGroups);
    } else {

        let queryString = `priceListGroupId=${inputOptions.priceGroupId}`;

        if (!inputOptions.fields) {
            queryString = queryString +'&fields=repositoryId,productId,skuId'
        }
        else{
            queryString = queryString + "&" + inputOptions.fields;
        }

        let result = '';

        let allPrices = priceGroupBuffer ? priceGroupBuffer : [];
        
        logger.debug("occ >> getPriceGroupPrices >> Getting prices for queryString: ", queryString);
        occClient.get({
            url: '/ccadmin/v1/prices?' +queryString,
            callback: function (err, response) {
                logger.debug("occServices.getPriceGroupPrices >> err:", JSON.stringify(err));
                logger.debug("occServices.getPriceGroupPrices >> response:", JSON.stringify(response));

                if (response && response instanceof Buffer) {
                    result = JSON.parse(response.toString());
                } else {
                    result = response;
                }

                if(err){
                    callback(err, result);
                }
                else if (result) {
                    if(result.items){
                        allPrices = allPrices.concat(result.items);
                        if (result.links && result.links.length > 0) {
                            const next = result.links.find(function (link) {
                                return link.rel === 'next';
                            });
                            if (next) {
                                const tempUrl = unescape(next.href);
                                const thisParams = tempUrl.split('?');
                                getAllPriceGroups(thisParams[1], allPrices, callback);
                            } else {
                                logger.debug("Invoking callback");
                                callback(err, allPrices);
                            }
                        }
                    }
                    else{
                        callback(response, allPrices);
                    }
                }
            }
        });
    }
};

//const occServices  = new OCCServices();
//console.log("occ >> occServices: ", JSON.stringify(OCCServices));

module.exports = occServices;

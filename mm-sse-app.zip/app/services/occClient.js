const CommerceSDK = require('../libraries/occ-sdk');
//
const nconf = require('nconf')
const mmConfig = require('../../config');

var HttpsProxyAgent = require('https-proxy-agent');

const occServerConfig = mmConfig.get('occ.server') || {}; 

console.log("occClient: mmConfig.get >> occ.server: ", mmConfig.get("occ.server"));

const getAdminHost = () => nconf.get('atg.server.admin.url').split('/').slice(0, 3).join('/');
const getStoreHost = () => nconf.get('atg.server.url').split('/').slice(0, 3).join('/');
const getApiKey = () => nconf.get('atg.application.credentials')['atg.application.token'];

if(nconf.get('atg.server.url')){
    var proxy = process.env.http_proxy || nconf.get('general:proxy-server');

    if (proxy) {
        occServerConfig.proxyUrl = proxy;
        occServerConfig.proxyAgent = new HttpsProxyAgent(proxy);
    }

    occServerConfig.port = 443;
    occServerConfig.hostname = getAdminHost();
    occServerConfig.storeUrl = getStoreHost();
    occServerConfig.hostname = getAdminHost();
    occServerConfig.apiKey = getApiKey();
}


console.info("occClient >> occServerConfig: " + JSON.stringify(occServerConfig));

const occClient = new CommerceSDK(occServerConfig);

/*const occClient = new CommerceSDK({
    hostname: 'p8014348c1dev-admin.occa.ocs.oraclecloud.com',
    port: '443',
    apiKey: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0ZGRlNGQxMy1jMTMwLTQ4MGYtYjM1NC0yNTgxYjMwMjliMjMiLCJpc3MiOiJhcHBsaWNhdGlvbkF1dGgiLCJleHAiOjE2NDc3MjAyNjIsImlhdCI6MTYxNjE4NDI2Mn0=.1V3ngqqnQguOQYShPiZO1b1ojGht11pks/W2PeEJS7k='
});*/

//console.log("occClient >> client:", JSON.stringify(occClient));

module.exports = occClient;
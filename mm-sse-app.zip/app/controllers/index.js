
const {
    ebsIntegrationController
} = require('./ebsIntegrationController');

const {
    occExternalSiteContractController
} = require('./occExternalSiteContractController');

const {
    ebsGetBsaController
} = require('./ebsGetBsaController');

const {
    pingController
} = require('./pingController');


const {
    ebsGetBsasController
} = require('./ebsGetBsasController');


module.exports = {
    ebsIntegrationController,
    occExternalSiteContractController,
    ebsGetBsasController,
    ebsGetBsaController,
    pingController
}
const logger = require('../../utils/GlobalLogger');
//const config = require('../../utils/Config');
const config = require('config');
const {postMethod, getMethod} = require('../../utils/httpMethod');
const occ = require('../services/occ');
const ebsServices = require('../services/ebs');


function respondError(httpResponse, errorCode, errorMessage, rawMessage) {
    let payload = {};
    payload.success = false;
    payload.errorCode = errorCode;
    payload.message = errorMessage;
    if(rawMessage){
        payload.rawMessage = rawMessage;
    }

    logger.debug("Sending error : " + JSON.stringify(payload));
    httpResponse.status(400).json(payload);
}

function respondSuccess(httpResponse, responsePayload) {
    
    httpResponse.status(200).json(responsePayload);
}



const pingController = (httpRequest, httpResponse) => {
    
       
        this.httpResponse = httpResponse;
        //occ.getAllPriceGroups(undefined, undefined, handleAllPriceGroups);
        respondSuccess(httpResponse, {reply: 'ok'});
       
};


module.exports = {
    pingController
};
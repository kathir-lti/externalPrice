const logger = require('../../utils/GlobalLogger');

const {postMethod, getMethod} = require('../../utils/httpMethod');
const ebsServices = require('../services/ebs');

function respondError(httpResponse, errorCode, errorMessage, rawMessage) {
    let payload = {};
    payload.success = false;
    payload.errorCode = errorCode;
    payload.message = errorMessage;
    if(rawMessage){
        payload.rawMessage = rawMessage;
    }

    logger.debug("Sending error : " + payload);
    httpResponse.status(400).json(payload);
}

function respondSuccess(httpResponse, responsePayload) {
    let payload = {};
    payload.success = true;
    payload.response = responsePayload;
    
    httpResponse.status(200).json(payload);
}

const ebsIntegrationController = (httpRequest, httpResponse) => {
    
        logger.debug("======>ebsIntegrationController : ");
        
        //logger.debug("httpReq.body : " + JSON.stringify( httpRequest.body));
        
        
        if (httpRequest.body) {
            
            let endpoint = ebsServices.getServerUrl() + "/" +  httpRequest.body.endpoint;
            let method = httpRequest.body.method;
            let payload = httpRequest.body.payload;

            logger.info("endpoint: "+ endpoint);
            logger.info("auth: "+ JSON.stringify(ebsServices.getAuthentication()));

            if (method == 'POST'){

                postMethod(endpoint, JSON.parse(payload), ebsServices.getAuthentication())
                    .then(result => {
                        //logger.debug("error: ", result);
                        respondSuccess(httpResponse, result);
                    })
                    .catch(function(err) {
                        //logger.debug("error: ", err.message);
                        respondError(httpResponse, 'error', 'Unexpected error occurred while executing endpoint.', err.message);
                    });
            }
            else if(method == 'GET'){
                getMethod(endpoint, ebsServices.getAuthentication())
                .then(result => {
                    //logger.debug("error: ", result);
                    respondSuccess(httpResponse, result);
                })
                .catch(function(err) {
                    //logger.debug("error: ", err.message);
                    respondError(httpResponse, 'error', 'Unexpected error occurred while executing endpoint.', err.message);
                });
            }
            
        }else{
            respondError(httpResponse, 'error', 'Payload is required.');
        }


        
    };


module.exports = {
    ebsIntegrationController
};
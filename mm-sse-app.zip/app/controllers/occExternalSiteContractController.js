const logger = require('../../utils/GlobalLogger');
const config = require('../../utils/Config');
const {postMethod} = require('../../utils/postMethod');

function respondError(httpResponse, errorCode, errorMessage, rawMessage) {
    let payload = {};
    payload.success = false;
    payload.errorCode = errorCode;
    payload.message = errorMessage;
    if(rawMessage){
        payload.rawMessage = rawMessage;
    }

    logger.debug("Sending error : " + payload);
    httpResponse.status(400).json(payload);
}

function respondSuccess(httpResponse, responsePayload) {
    
    httpResponse.status(200).json(responsePayload);
}


const occExternalSiteContractController = (httpRequest, httpResponse) => {
    
        //logger.debug("httpReq.body : " + JSON.stringify( httpRequest.body));
        
        
        if (httpRequest.body) {
            
            let result = {};
            
            result.message = "MM External Site SSE";
            result.defaultPriceListGroup = undefined;
            result.defaultCatalog = undefined;

            
            logger.debug("======>occExternalSiteContractController : request: ", httpRequest.body.request);
        
            if(httpRequest.body.request){
                let occRequest = httpRequest.body.request;
                logger.debug("======>occExternalSiteContractController : occRequest: ", JSON.stringify(occRequest));
                
                if(occRequest.contextData && occRequest.contextData.userContext && occRequest.contextData.userContext){

                    let userContext = JSON.parse(occRequest.contextData.userContext);
                    if(userContext && userContext.bsa){
                        result.defaultPriceListGroup = userContext.bsa.priceGroupId;
                    }
                }

                if(occRequest.profile){
                    if(!result.defaultPriceListGroup)
                        result.defaultPriceListGroup = occRequest.profile.priceListGroup.repositoryId;
                    result.defaultCatalog = occRequest.profile.catalog.id;
                }
                result.responseCode = 1;
            }else{
                result.responseCode = 0;
            }

            respondSuccess(httpResponse, result);
               
        }else{
            respondError(httpResponse, 'error', 'Payload is required.');
        }


        
    };


module.exports = {
    occExternalSiteContractController
};
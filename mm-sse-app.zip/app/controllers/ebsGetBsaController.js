const logger = require('../../utils/GlobalLogger');
//const config = require('../../utils/Config');
const config = require('config');
const {postMethod, getMethod} = require('../../utils/httpMethod');
const occ = require('../services/occ');
const ebsServices = require('../services/ebs');


function respondError(httpResponse, errorCode, errorMessage, rawMessage) {
    let payload = {};
    payload.success = false;
    payload.errorCode = errorCode;
    payload.message = errorMessage;
    if(rawMessage){
        payload.rawMessage = rawMessage;
    }

    logger.debug("Sending error : " + JSON.stringify(payload));
    httpResponse.status(400).json(payload);
}

function respondSuccess(httpResponse, responsePayload) {
    let payload = {};
    payload.success = true;
    payload.response = responsePayload;
    
    httpResponse.status(200).json(payload);
}


const handlePriceGroupPrices = (error, result) => {
    logger.debug("ebsGetBsaController >> prices", result);
    if(error){
        logger.error("Error occured while getting prices for price group");
        logger.error(JSON.stringify(error));

        if(result.errorCode){
            respondError(this.httpResponse, result.errorCode, result.message, error);
        }
        else{
            respondError(this.httpResponse, 'error', (error.message)? error.message : 'Unexpected error occured while getting prices');
        }

    }else{
        respondSuccess(this.httpResponse, result);
    }
}

const ebsGetBsaController = (httpRequest, httpResponse) => {
    
        logger.debug("======>ebsGetBsaController : ENTER");
        logger.debug("ebsGetBsaController: params: ", JSON.stringify(httpRequest.params));
        
        this.httpResponse = httpResponse;
        //occ.getAllPriceGroups(undefined, undefined, handleAllPriceGroups);
        
        const accountNumber = httpRequest.params['accountNumber'];
        const includeHeader = httpRequest.params['includeHeader'] || true;
        const includeLines = httpRequest.params['includeLines'] || true;
        const bsaNumber = httpRequest.params['bsaNumber'];
        logger.debug("ebsGetBsaController >> bsaNumber : " + bsaNumber);
        /* 
        if(bsaNumber){    
            occ.getPriceGroupPrices({priceGroupId: `bsa_${bsaNumber}`}, [], handlePriceGroupPrices);
        }
        else{
            respondError(httpResponse, 'error', 'Unexpected error occurred while executing endpoint.', err.message);
        }    */  
        
        if(bsaNumber){
            let endpoint = ebsServices.getServerUrl() + ebsServices.getBSAPath();
            logger.info("ebsGetBsaController >> endpoint: ", JSON.stringify(endpoint));
            
            
            const payload = {
                "bsaNumber":  bsaNumber,
                "includeHeader" : includeHeader,
                "includeLines": includeLines
            };

            logger.info("ebsGetBsaController >> payload: " + JSON.stringify(payload));

            postMethod(endpoint, payload, ebsServices.getAuthentication())
                .then(result => {
                    //logger.debug("error: ", result);
                    respondSuccess(httpResponse, result);
                })
                .catch(function(err) {
                    //logger.debug("error: ", err.message);
                    respondError(httpResponse, 'error', 'Unexpected error occurred while executing endpoint.', err.message);
                });
        }else{
            respondError(httpResponse, 'error', 'Account number is required.');
        }
    };


module.exports = {
    ebsGetBsaController
};
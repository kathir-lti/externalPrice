const logger = require('../../utils/GlobalLogger');
//const mmConfig = require('../../config');
const {postMethod, getMethod} = require('../../utils/httpMethod');
//const occServices = require('../services/occ');
const ebsServices = require('../services/ebs');
const utilities = require('../../utils/Utilities');

function respondError(httpResponse, errorCode, errorMessage, rawMessage) {
    let payload = {};
    payload.success = false;
    payload.errorCode = errorCode;
    payload.message = errorMessage;
    if(rawMessage){
        payload.rawMessage = rawMessage;
    }

    logger.info("Sending error : " + JSON.stringify(payload));
    httpResponse.status(400).json(payload);
}

function respondSuccess(httpResponse, responsePayload) {
    let payload = {};
    payload.success = true;
    payload.response = responsePayload;
    logger.info("Response : " + JSON.stringify(responsePayload));   
    httpResponse.status(200).json(payload);
}

/* 
const handleAllPriceGroups = (error, priceGroups) => {
    logger.info("ebsGetBsasController >> priceGroups", priceGroups);
} */

const ebsGetBsasController = (httpRequest, httpResponse) => {
    
        logger.debug("======>ebsGetBsasController : ENTER");
        //occServices.getAllPriceGroups(undefined, undefined, handleAllPriceGroups);
        //logger.debug("httpReq.body : " + JSON.stringify( httpRequest.body));
            
        const accountNumber = httpRequest.params['accountNumber'];
        logger.info('Account Number: '+ accountNumber);

        if(accountNumber){
            let endpoint = ebsServices.getServerUrl() + ebsServices.getBSAsPath() + "/" + accountNumber;
            logger.debug("endpoint: " + endpoint);
            
            getMethod(endpoint, ebsServices.getAuthentication())
                .then(result => {
                    logger.debug("error: ", result.data);
                    respondSuccess(httpResponse, result.data);
                }, error =>{
                    logger.debug("Error(1): " + error);
                    logger.debug("Error(2): " + error.response);
                    logger.debug("Error: " + JSON.stringify(error));
                    respondError(httpResponse, 'error', 'Unexpected error occurred while executing endpoint.', (utilities.isEmptyObject(error) ? 'Unknown Error.' : error.message));
                })
                .catch(error => {
                    logger.debug("Unexpected error occurred while executing endpoint: " + endpoint);
                    logger.debug("Error(1): " + error);
                    logger.debug("Error(2): " + error.response);
                    logger.debug("Error: " + JSON.stringify(error));
                    
                    //logger.debug("Error " + `Error: ${error?.response?.data}`);
                    respondError(httpResponse, 'error', 'Unexpected error occurred while executing endpoint.', (utilities.isEmptyObject(error) ? 'Unknown Error.' : error.message));
                });
        }else{
            respondError(httpResponse, 'error', 'Account number is required.');
        }
        
    };


module.exports = {
    ebsGetBsasController
};
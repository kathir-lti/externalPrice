const fs = require('fs');
const path = require('path');
const logger = require('../utils/GlobalLogger');

const env = process.env.NODE_ENV;
logger.info("mmConfing >> env ===> ", env);

let configObject = {};

const getValue = (configObject, property) => {
        
    const elems = Array.isArray(property) ? property : property.split('.'),
    name = elems[0],
    value = configObject[name];
    if (elems.length <= 1) {
        return value;
    }
    // Note that typeof null === 'object'
    if (value === null || typeof value !== 'object') {
        return undefined;
    }
    return getValue(value, elems.slice(1));
}


var mmConfig = function() {
    var t = this;
    const load = () => {
        logger.info("---------mmConfig------");
        logger.info("mmConfing >> env: "+ env);
        logger.info("mmConfing >> __dirname: "+ __dirname);

        let configName =  env || 'local';
        logger.info("mmConfing >> configName: " + configName, env);

        let fileContent = fs.readFileSync(path.join(__dirname,`./${configName}.json`), 'UTF-8');
        configObject = JSON.parse(fileContent);

        
    }

    load();
}

mmConfig.prototype.get = function(property) {
    if(property === null || property === undefined){
      throw new Error("Calling mmConfig.get with null or undefined argument");
    }
  
    var t = this,
    value = getValue(configObject, property);
  
  
    /* if (value === undefined) {
      throw new Error('Configuration property "' + property + '" is not defined');
    } */
  
    // Return the value
    return value;
  };



var config = module.exports = new mmConfig();
# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://mutualmaterials.com)

### How do I get set up? ###

* Summary of set up
1. Download the source code from OCC
2. Execute "yarn install" to download and install the dependencies


* Configuration
This SSE app requires the configration for OCC, EBS (and other third-party servers). etc.
The configrations are mentioned in the "config/default.json" and "config/development.json".
The local execution of the app requires the configration to be updated in "config/local.json" file.

- config/local.json
- config/default.json
- config/development.json

* Dependencies
The dependencies are mentioned in the package.json file

* How to run
1. Execute "node ./index.js" to start the server

* Deployment instructions
1. Rename the module nconf to something else e.g. #1nconf
2. Zip all the files and folders
3. Upload the file using POST /ccadmin/v1/serverExtensions REST API call.

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### How do I build and run? ###

### Who do I talk to? ###

* Kavan Shah, iBizSoft Inc. / APEX IT
* Derek Solis, Mutual Materials